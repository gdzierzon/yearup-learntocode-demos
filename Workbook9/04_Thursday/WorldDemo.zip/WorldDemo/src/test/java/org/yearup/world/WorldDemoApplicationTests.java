package org.yearup.world;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WorldDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
